
__version__ = '@CGAL_VERSION@'
