// ------------------------------------------------------------------------------
// Copyright (c) 2011 GeometryFactory (FRANCE)
// SPDX-License-Identifier: GPL-3.0-or-later OR LicenseRef-Commercial
// ------------------------------------------------------------------------------ 

#ifndef SWIG_CGAL_ALPHA_SHAPE_2_CONFIG_H
#define SWIG_CGAL_ALPHA_SHAPE_2_CONFIG_H

#ifdef SWIGJAVA
#define ADD_JAVA_DATA_IN_FACE_AS2 
#endif

#endif //SWIG_CGAL_ALPHA_SHAPE_2_CONFIG_H
