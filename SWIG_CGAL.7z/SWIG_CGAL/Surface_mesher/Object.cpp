// ------------------------------------------------------------------------------
// Copyright (c) 2011 GeometryFactory (FRANCE)
// SPDX-License-Identifier: GPL-3.0-or-later OR LicenseRef-Commercial
// ------------------------------------------------------------------------------ 


#define SWIG_CGAL_SURFACE_MESHER_EXPORT

#include <SWIG_CGAL/Surface_mesher/Object.h>
